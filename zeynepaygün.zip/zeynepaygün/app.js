const caracterInput=document.getElementById('caracterinput')
const container = document.getElementById('container')



const baseURL='https://pokeapi.co/api/v2/'

function addCaracterToCard(element,feature){
    console.log(feature)
        
        for(i=1; i<feature.length ;i++){
           
            element.innerHTML+=`
            <div id="card" style="font-size:30px;color:grey;font-weight:bold;">
              ${feature[i].name}
              
              <img  style="width:200px"src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/dream-world/${[i]}.svg">
            </div> `
            

            
        }
    // console.log(feature+'+'+element)
}

async function getAllCaracter(){
    let res=await fetch(`${baseURL}pokemon/`)
    let allCaracter=await res.json()
    
    
    // console.log(allCaracter)
    allList = allCaracter.results
    

    //console.log(allList)
    addCaracterToCard(container, allList)
    // allList.splice(0,allList.length);
    
}
async function GetCaracter(caracter){
    let res=await fetch(`${baseURL}pokemon/${caracter}`)
    let caracterget=await res.json()

    console.log(caracterget)
    // addCaracterToCard(CardEl,caracterget)

     container.innerHTML += `
     <div id="card">
     <div class="id" style="color:black;font-size:20px;font-weight:bold">${caracterget.id} </div>
     <div class="name" style="color:grey;font-size:30px;font-weight:bold">${caracterget.name}</div>
     <div class="height">height:${caracterget.height}</div>
     <div class="weight">weight:${caracterget.weight}</div>
     <img class="image" style="width:200px"src="${caracterget.sprites.other.home.front_default}">
     </div> 
     
    `
   
}

function setInputCaracter(){

    let caractervalue=caracterInput.value
    console.log(caractervalue)
    GetCaracter(caractervalue)
    
}
getAllCaracter()

